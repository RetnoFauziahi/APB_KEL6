import 'package:flutter/material.dart';

class Pagetesting extends StatelessWidget {
  @override
  Widget build(BuildContext) {
    return Scaffold(
        appBar: AppBar(
      title: Text("Page Testing"),
    ));
  }
}
